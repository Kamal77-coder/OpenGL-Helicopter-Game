#include <stdio.h>

int	ReadInt(FILE *);
short	ReadShort(FILE *);
unsigned char * BmpToTexture(char *filename, int *width, int *height);